package eeps;

public class EEPS {

    public static void main(String[] args) {
    
    
    upgradeTrainee as = new upgradeTrainee();
    as.setVisible(true);


    }
    
}
