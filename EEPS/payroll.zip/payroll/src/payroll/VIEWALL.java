/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payroll;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;


/**
 *
 * @author Ahmed Soliman
 */
public class VIEWALL extends JFrame {

    JTable t  ;
         JScrollPane jsp ; 
        TableModel  model ; 
        
    Object rows[][]= {{" "," "," "," "," "," "," "},{" "," "," "," "," "," "," "},{" "," "," "," "," "," "," "}} ;
    String columns[] = {"Id" , "Name" ,"age","position", "working hours","Tax rate","pay rate"} ; 
    
    public VIEWALL (){
        
    model  = new DefaultTableModel(rows , columns) ;
      
        t = new JTable(model) ;
        jsp = new JScrollPane(t, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
          JFrame f = new JFrame("View All") ;
        f.setLayout (new BorderLayout() ) ;
        f.setSize(400, 300);
        t.setSize(400, 300);
        t.setLayout(new BorderLayout()) ;
        f.add (jsp,BorderLayout.CENTER ) ;
         f.setLocationRelativeTo(null);
         f.setVisible(true );
         f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         
    
    
    
    }
   
    
     public static void main (String args[]) {
     
     
      VIEWALL view = new VIEWALL() ;
         
    }



}