/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payroll;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author Ahmed Soliman
 */
public class VIEWALLTRAINEE  extends JFrame{
    
    JTable traineetable  ;
         JScrollPane jsp1 ; 
        TableModel  model1 ; 
        
    Object rows[][]= {{" "," "," "," "," "," "},{" "," "," "," "," "," "},{" "," "," "," "," "," "}} ;
    String columns[] = {"Id" , "Name" ,"age","University Name", "GPA","Academic year"} ; 
    
    public VIEWALLTRAINEE (){
        
    model1  = new DefaultTableModel(rows , columns) ;
      
        traineetable = new JTable(model1) ;
        jsp1 = new JScrollPane(traineetable, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
          JFrame f1 = new JFrame("View All") ;
        f1.setLayout (new BorderLayout() ) ;
        f1.setSize(400, 300);
        traineetable.setSize(400, 300);
        traineetable.setLayout(new BorderLayout()) ;
        f1.add (jsp1,BorderLayout.CENTER ) ;
         f1.setLocationRelativeTo(null);
         f1.setVisible(true );
         f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         
    
    
    
    }
   
    
     public static void main (String args[]) {
     
     
      VIEWALLTRAINEE viewtrainee = new VIEWALLTRAINEE() ;
         
    }



}

